log, ref, version, commit = "320b1987 Merge branch '923-encyclopedia-2d-and-1d-visualization-improvement' into 'v0.10.13'", "pipelines/135579", "v0.10.7-138-g320b1987", "320b1987"
